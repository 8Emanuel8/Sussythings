Download Minecraft forge for minecraft 1.16.5  --BY Eloraam and SpaceToad--
Extract the zip file, drag it into your mod folder( if you don't have one create it)
Create a Minecraft installation, select forge as version, select the sussythings mod folder as mod folder
Click play, once the game opens quit
Enter the sussythings mod folder and a lot of folders should be generated, one of wich named mods
-- you can put there as many mods as you want--
but just put in "mods" the .Jar file i provided to you
Once you open again Minecraft you can play my mod, enjoy!

Sussythings is a mod made by Emanuel8_07 with Mcreator, a platform for minecraft mods creation developed by Pylo.