Download Minecraft forge 1.16.5  --BY Eloraam of Redpower and SpaceToad of Buildcraft--
Extract this file, drag it into your mod folder( if you don't hve one create it)
Create a Minecraft installation, select forge as version, select the sussythings mod folder as mod folder
Click play, once the game opens quit
Enter the sussythings mod folder and a lot of folders should be generated, one of wich named mods
-- you can put there as many mods as you want--
but just put in "mods" the .Jar file i provided to you
Once you open again Minecraft you can play my mod, enjoy!